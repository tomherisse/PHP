<h2>Connexion</h2>
<?php echo validation_errors();?>
<?php echo form_open('jeux/index')?>
<label for="nomj">Identifiant</label>
<input type="input" name="nomj" /><br/>
<label for="mdpj">Mot de passe</label>
<input type="input" name="mdpj" /><br/>
<input type="submit" name="submit" value="Connexion" />
</form>
