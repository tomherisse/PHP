<?php
$this->load->view('form');
$this->load->view('listejeux');
?>
