<?php
class Jeux extends CI_Controller {

public function __construct(){
parent::__construct();
$this->load->model('jeux_model');
$this->load->helper('url');
}

public function index(){
$this->load->helper('form');
$this->load->library('form_validation');
$data['title']='Liste des jeux'; // a title to display above thelist
$data['content']='main'; // template will call 'task_list ' sub -view
$this->form_validation->set_rules('nomj','mdpj','required');
if($this->form_validation->run()!==FALSE){
    $identifiant=$this->input->post('nomj');
    $motdepasse=$this->input->post('mdpj');
    //$this->jeux_model->connex($identifiant,$motdepasse);
    $data['listejeux']=$this->jeux_model->connex($identifiant,$motdepasse);
    if ($data['listejeux']!=null){
        $data['content']='mesjeux';
    }
}
//$data['listejeux']=$this->jeux_model->get_jeux($identifiant);
$this->load->vars($data );
$this->load->view('template');

}


public function delete($id){
$this->jeux_model->delete_jeu($id);
$this->index();
}
	
}
?>
